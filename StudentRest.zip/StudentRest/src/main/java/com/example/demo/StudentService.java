package com.example.demo;

import java.util.List;

public interface StudentService {
	List<Student> findAllStudents();
	Student findLargest();
	Student findLowest();
}
