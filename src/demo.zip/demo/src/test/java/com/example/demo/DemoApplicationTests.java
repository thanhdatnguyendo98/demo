package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
class DemoApplicationTests {
	
	@Autowired
	private ApplicationContext applicationContext;

	@Test
	public void testListStudentSize() {
		StudentListBean dept = applicationContext.getBean(StudentListBean.class);
		int sizeExpected = 4;
		assertEquals(sizeExpected,dept.getListOfStudents().size());
	}

	@Test
	public void checkLargestStudentName() {
		StudentListBean dept = applicationContext.getBean(StudentListBean.class);
		String nameExpected = "dat";
		assertEquals(nameExpected, dept.findLargestStudent(dept));
	}
	
	@Test
	public void checkLowestStudentName() {
		StudentListBean dept = applicationContext.getBean(StudentListBean.class);
		String nameExpected = "hau";
		String nameExecuted = dept.findLowestStudent(dept);
		assertEquals(nameExpected, nameExecuted);
	}
	
	@Test 
	public void checkShowStudents() {
		StudentListBean dept = applicationContext.getBean(StudentListBean.class);
		
	}
}
