package com.example.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(DemoApplication.class, args);
		StudentListBean dept = context.getBean("studentListBean", StudentListBean.class);

		// show students
		dept.showStudents(dept);

		// find student who has the largest GPA
		System.out.println("Student has the largest GPA: " + dept.findLargestStudent(dept));

		// find student who has the smallest GPA
		System.out.println("Student has the lowest GPA: " + dept.findLowestStudent(dept));

	}

}
