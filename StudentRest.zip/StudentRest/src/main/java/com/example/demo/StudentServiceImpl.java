package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;


public class StudentServiceImpl {
	
	private static final AtomicLong counter = new AtomicLong();
	
	private static List<Student> students;
	
	static{
		students= populateStudents();
	}
	
	public List<Student> findAllUsers() {
		return students;
	}

	private static List<Student> populateStudents(){
		List<Student> students = new ArrayList<Student>();
		students.add(new Student(counter.incrementAndGet(),"Sam",30, 70000));
		students.add(new Student(counter.incrementAndGet(),"Tom",40, 50000));
		students.add(new Student(counter.incrementAndGet(),"Jerome",45, 30000));
		students.add(new Student(counter.incrementAndGet(),"Silvia",50, 40000));
		return students;
	}
}
