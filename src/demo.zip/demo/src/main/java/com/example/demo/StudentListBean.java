package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
 
import java.util.List;
 
/**
 * Created by Turreta.com on 8/7/2017.
 */
@Component
public class StudentListBean
{
    @Autowired
    private List<StudentBean> listOfStudents;
    
	private StudentBean stu = new StudentBean();

	public List<StudentBean> getListOfStudents() {
		return listOfStudents;
	}

	public void setListOfStudents(List<StudentBean> listOfStudents) {
		this.listOfStudents = listOfStudents;
	}
   
	// Show students
	public void showStudents(StudentListBean listOfStudents) {
		for (StudentBean student : listOfStudents.getListOfStudents()) {
			System.out.println(student.toString());
		}
	}
	
	// Find student have largest GPA
	public String findLargestStudent(StudentListBean listOfStudents) {
		for (StudentBean student : listOfStudents.getListOfStudents()) {
			for (int i = 0; i < listOfStudents.getListOfStudents().size(); i++) {
				if (listOfStudents.getListOfStudents().get(i).getGPA() > stu.getGPA()) {
					stu = listOfStudents.getListOfStudents().get(i);
				}
			}
		}
		return stu.getName();
	}
	
	// Find student have lowest GPA
	public String findLowestStudent(StudentListBean listOfStudents) {
		for (StudentBean student : listOfStudents.getListOfStudents()) {
			for (int i = 0; i < listOfStudents.getListOfStudents().size(); i++) {
				if (listOfStudents.getListOfStudents().get(i).getGPA() < stu.getGPA()) {
					stu = listOfStudents.getListOfStudents().get(i);
				}
			}
		}
		return stu.getName();
	}
	
	
}